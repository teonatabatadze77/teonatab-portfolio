# QA Test Cases Portfolio

This repository contains **sample manual QA test cases** prepared for GitHub portfolio use.

## About
- Language: English
- All data is anonymized
- Jira-style test case structure

## Skills Demonstrated
- Manual Testing
- Test Case Design
- QA Documentation

## Disclaimer
All test cases are fictional and created for portfolio purposes only.
